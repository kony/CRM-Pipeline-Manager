function AS_FlexContainer_37530c8b99f74098bf1d0d86ebb7ce4b(eventobject) {
    sliderMenu();
    frmLoginVA.show();
}