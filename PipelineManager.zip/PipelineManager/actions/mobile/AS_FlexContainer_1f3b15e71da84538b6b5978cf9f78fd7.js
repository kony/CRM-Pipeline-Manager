function AS_FlexContainer_1f3b15e71da84538b6b5978cf9f78fd7(eventobject) {
    sliderMenu();
    frmDashboardKA.show();
}