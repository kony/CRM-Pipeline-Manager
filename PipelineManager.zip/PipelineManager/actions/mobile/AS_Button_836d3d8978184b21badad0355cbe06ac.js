function AS_Button_836d3d8978184b21badad0355cbe06ac(eventobject) {
    frmOpportunityList.show();
}