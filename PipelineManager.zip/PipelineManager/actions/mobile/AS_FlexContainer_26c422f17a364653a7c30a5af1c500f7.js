function AS_FlexContainer_26c422f17a364653a7c30a5af1c500f7(eventobject) {
    kony.print("myString");
}