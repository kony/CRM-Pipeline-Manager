function AS_FlexContainer_247f13d687c44ca0ba1c2b2b0598447c(eventobject) {
    sliderMenu();
    frmOpportunityListKA.show();
}