function AS_Button_7cd299b680d44fd2bee0550463031bcc(eventobject) {
    rememberMeFuntionality();
}