function AS_FlexContainer_06a685703a68421dbe4f1e65bd50688d(eventobject) {
    sliderMenu();
    frmOpportunityListKA.show();
}