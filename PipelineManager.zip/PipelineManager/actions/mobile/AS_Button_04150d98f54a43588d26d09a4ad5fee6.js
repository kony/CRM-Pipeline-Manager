function AS_Button_04150d98f54a43588d26d09a4ad5fee6(eventobject) {
    kony.phone.dial(frmAccountDetails.lblPhoneNumKA.text);
}